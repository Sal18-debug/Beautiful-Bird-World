var unirest = require("unirest");

var req = unirest("POST", "https://face-ai.p.rapidapi.com/faces/detect/");

req.headers({
"x-rapidapi-host": "face-ai.p.rapidapi.com",
"x-rapidapi-key": "33179136b2mshc66e07cecd059ddp130dbbjsn54a479c20abd",
"content-type": "multipart/form-data",
"useQueryString": true
});

req.multipart([
{
"image": "<file goes here>",
"content-type": "application/octet-stream"
}
]);

req.end(function (res) {
if (res.error) throw new Error(res.error);

console.log(res.body);
console.log(res.body);
});





  