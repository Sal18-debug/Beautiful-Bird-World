var unirest = require("unirest");

var req = unirest("POST", "https://face-ai.p.rapidapi.com/faces/detect/");

req.headers({
	"x-rapidapi-host": "face-ai.p.rapidapi.com",
	"x-rapidapi-key": "33179136b2mshc66e07cecd059ddp130dbbjsn54a479c20abd",
	"content-type": "multipart/form-data",
	"useQueryString": true
});

req.multipart([
	{
		"image": "<file goes here>",
		"content-type": "application/octet-stream"
	}
]);

req.end(function (res) {
	if (res.error) throw new Error(res.error);

	console.log(res.body);
});

https://rapidapi.com/simpliya-ltd-platform/api/face-ai?endpoint=apiendpoint_72d9dabd-b603-4bbf-a6e0-966de93fcc99

Bird URL

https://www.programmableweb.com/api/ebird-rest-api-v20

#e7b5b3

24jennhhdun8 Api Key
