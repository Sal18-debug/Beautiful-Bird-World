function loadLiveData(){
	var settings = {
		"async": true,
		"crossDomain": true,
		"url": "https://coronavirus-monitor.p.rapidapi.com/coronavirus/worldstat.php",
		"method": "GET",
		"headers": {
			"x-rapidapi-host": "coronavirus-monitor.p.rapidapi.com",
			"x-rapidapi-key": "ef16c6e447msha63c8a0ea801e28p11fc13jsn2836d6d57b63"
		}
https://rapidapi.com/simpliya-ltd-platform/api/face-ai?endpoint=apiendpoint_72d9dabd-b603-4bbf-a6e0-966de93fcc99


var unirest = require("unirest");

var req = unirest("POST", "https://face-ai.p.rapidapi.com/faces/detect/");

req.headers({
"x-rapidapi-host": "face-ai.p.rapidapi.com",
"x-rapidapi-key": "33179136b2mshc66e07cecd059ddp130dbbjsn54a479c20abd",
"content-type": "multipart/form-data",
"useQueryString": true
});

req.multipart([
{
"image": "<file goes here>",
"content-type": "application/octet-stream"
}
]);

req.end(function (res) {
if (res.error) throw new Error(res.error);

console.log(res.body);
console.log(res.body);
});





    $.ajax(settings).done(function (response) {
		var responseObj = JSON.parse(response);
		document.getElementById('lblLastUpdateDate').innerHTML = responseObj.statistic_taken_at;	
		document.getElementById('lblTotalCases').innerHTML = responseObj.total_cases;
		document.getElementById('lblNewCases').innerHTML = responseObj.new_cases;
		document.getElementById('lblTotalDeaths').innerHTML = responseObj.total_deaths;
		document.getElementById('lblNewDeaths').innerHTML = responseObj.new_deaths;
		document.getElementById('lblTotalRecovered').innerHTML = responseObj.total_recovered;
		document.getElementById('lblActiveCases').innerHTML = responseObj.active_cases;
		document.getElementById('lblSeriousCases').innerHTML = responseObj.serious_critical;
	});
}